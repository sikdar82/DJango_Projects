## Weather-App 

A Web Application created using Django Framework for displaying the current weather of any city in the entire world.

[OpenWeatherMap](https://openweathermap.org) API used to access the live weather details.

[Bulma](https://bulma.io/) Framework for the css layout cuz it's easy and attractive. <br />

Cities can be managed via admin area too.

Make sure to run manage.py while in My_Weather_Webapp
