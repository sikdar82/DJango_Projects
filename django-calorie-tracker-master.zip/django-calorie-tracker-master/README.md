# django-calorie-tracker
The intention here is to create a web app using Djnago that tracks calories intake and track the calories consumptions.

# SKILL SET REQUIRED:
 Django, Python, BootStrap, HTML, Javascript, CSS


# RESULT:
![image](https://user-images.githubusercontent.com/46977634/92306334-36119700-ef86-11ea-83ac-ef08373529ff.png)
